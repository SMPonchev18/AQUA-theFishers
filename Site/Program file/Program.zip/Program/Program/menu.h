#pragma once

using namespace std;

extern string user_status;

void printMenu();

void askForStatus();

string inputStatus();

int inputChoice();

void choice(int user_choice);

void printSpecies();

void printUsage();

void printTeamInformation();

void returnToMenu();