#include <iostream>
#include "functions.h"

using namespace std;

int main()
{
	askForStatus();
}